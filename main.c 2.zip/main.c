/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vuslysty <vuslysty@student.unit.ua>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/24 14:39:58 by vuslysty          #+#    #+#             */
/*   Updated: 2018/10/24 18:55:46 by vuslysty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include "libft.h"
//#include <ctype.h>
//#include<stdlib.h>
//
//void del(void *content, size_t size)
//{
//    ft_memdel(&content);
//}
//
//int main(void)
//{
//    
////    char dst1[10] = "Hello";
////    char dst2[10] = "Hello";
////    char src[10] = "world";
////
////    int size = 10;
////
////    int i = ft_strlcat(dst1, src, size);
////    int j = strlcat(dst2, src, size);
////    printf("%s\n%i\n", dst1, i);
////    printf("%s\n%i\n", dst2, j);
//
////    t_list *list = ft_lstnew("Hello", 6);
////    list->next = ft_lstnew("World", 6);
//    
//    t_list *list = NULL;
//    ft_lstadd(&list, ft_lstnew("Hello", 6));
//    ft_lstadd(&list, ft_lstnew("WORLD", 6));
//    
//    printf("%s\n%s\n%p\n", list->content, list->next->content, list->next->next);
//    ft_lstdel(&list, del);
//    printf("%p", list);
//    
//    return (0);
//}

