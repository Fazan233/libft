/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vuslysty <vuslysty@student.unit.ua>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/24 14:39:58 by vuslysty          #+#    #+#             */
/*   Updated: 2018/10/24 18:55:46 by vuslysty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "libft.h"
#include <ctype.h>
#include<stdlib.h>

int main(void)
{
    /*
     //strlen test
     char *test = "Hello";
     //  printf("%zu\n", ft_strlen(test));
     //stecpy test
     char test_cpy1[20];
     char test_cpy2[] = "Hello World";
     
     ft_strcpy(test_cpy1, test);
     printf("%s\n", test_cpy1);
     ft_strcpy(test_cpy1, test_cpy2);
     printf("%s\n", test_cpy1);
     ft_strcpy(test_cpy1, test);
     printf("%s\n", test_cpy1);
     
     char str1[30] = "abcdefg";
     char str2[100] = "ab";
     
     char *a = str1;
     char *b = str1;
     
     strncpy(a + 3, b, 15);
     printf("%s\n", a);
     
     int i = -1;
     while (++i < 30)
     printf("%i ", str1[i]);
     */
    
//    int len;
//    char *a;
    
//    a = ft_strdup("");
//	printf("%s\n", a);
    
//    char str1[10] = "aaaa1aa";
//    char str2[10] = "aaaaaa2";
//    int a = ft_strncmp(str1, str2, 20);
//    int b = strncmp(str1, str2, 20);
//    int a = ft_tolower('A' - 1);
//    int b = tolower('A' - 1);
    
//    printf("%i %i\n", a, b);

    
/*    int i = -1;
*    while (++i < 30)
    printf("%i ", str1[i]);
*/
//    char *str1 = "0123456789";
//    char *str2 = "1234";
//    char *a = ft_strnstr(str1, str2, 5);
//    char *b = strnstr(str1, str2, 5);
//
//    printf("%p\n%p\n", a, b);
    
//    a = ft_strchr(str, 'o');
//    b = strchr(str, 'o');
//
//    printf("%p\n%p\n", a, b);
//char str1[20] =  "program";
    //char str2[20] =  "prodefg";
//    int arr1[5] = {5, 4, 3, 2, 1};
//    int arr2[5] = {1, 2, 3, 4, 5};

    
//    memccpy(str1, str2, 'l', 5);
/*
    for (int i = 0; i < 5; i++)
        printf("%i ", arr1[i]);
    printf("\n");
    for (int i = 0; i < 5; i++)
        printf("%i ", arr1[i]);
*/
//    printf("%i\n", atoi("1000000000000000000"));
//    printf("%i\n", atoi("9090000000000000000"));
//    printf("%s\n", ft_memchr(str1, 'r', 1));
//    printf("%s\n", memchr(str1, 'r', 1));
//    printf("%s\n", str1);
//    printf("%i\n", ft_memcmp(str1, str2, 10));
    
    int *str;
    str = (int*)ft_memalloc(20);
    
    int i = -1;
    while (++i < 10)
    {
        printf("%i\n", str[i]);
    }
    
 return (0);
}
